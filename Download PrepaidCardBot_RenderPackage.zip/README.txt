
🚀 Prepaid Card Telegram Bot – Hosting Guide (Render)

1. Go to https://render.com and create a free account
2. Click 'New' > 'Web Service'
3. Connect your GitHub OR upload manually
4. Make sure your service is:
   - Build command: pip install -r requirements.txt
   - Start command: python3 main.py
   - Environment: Python
5. Done! Your bot is now hosted 24/7 for FREE

Bot will restart if it crashes. SQLite will persist if you use external volume.
